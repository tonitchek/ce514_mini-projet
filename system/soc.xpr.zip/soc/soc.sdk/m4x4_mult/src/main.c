/*
 * main.c
 *
 *  Created on: Oct 8, 2017
 *      Author: broquet
 */
#include <stdio.h>
#include <stdint.h>
#include "xtime_l.h"
#include "xparameters.h"
#include "xil_io.h"

int main(void)
{
	XTime begin,end,offset,begin1,end1;
	uint32_t base_address = XPAR_MATRIX_4X4_MULTIPLIER_0_S00_AXI_BASEADDR;

	printf("\r\n\r\n--------\r\nTest Matrix calcul with inhibit (SW0 set to HIGH)\r\n");
	XTime_GetTime(&begin);
	XTime_GetTime(&end);
	offset = end - begin;
	printf("Offset Time: %.9lf\r\n",(double)(offset)*(1.0/COUNTS_PER_SECOND));

	printf("Read CSR: 0x%08x\r\n",Xil_In32(base_address+0));
	printf("TIMER test\r\n");
	printf("Enable timer\r\n");
	Xil_Out32(base_address+0,0x4);
	printf("Read TIMER: 0x%08x\r\n",Xil_In32(base_address+4));
	printf("Read TIMER: 0x%08x\r\n",Xil_In32(base_address+4));
	printf("Disable timer\r\n");
	Xil_Out32(base_address+0,0);
	printf("Read TIMER: 0x%08x\r\n",Xil_In32(base_address+4));
	printf("Read TIMER: 0x%08x\r\n",Xil_In32(base_address+4));
	printf("Clear timer\r\n");
	Xil_Out32(base_address+0,0x8);
	printf("Read TIMER: 0x%08x\r\n",Xil_In32(base_address+4));
	printf("Read TIMER: 0x%08x\r\n",Xil_In32(base_address+4));

	//set auto timer bit
	Xil_Out32(base_address+0,0x10);
	printf("Read CSR: 0x%08x\r\n",Xil_In32(base_address+0));
	printf("Read TIMER: 0x%08x\r\n",Xil_In32(base_address+4));
	printf("Read TIMER: 0x%08x\r\n",Xil_In32(base_address+4));
	printf("Enable timer\r\n");
	Xil_Out32(base_address+0,0x14);
	printf("Read TIMER: 0x%08x\r\n",Xil_In32(base_address+4));
	printf("Read TIMER: 0x%08x\r\n",Xil_In32(base_address+4));
	printf("Disable timer\r\n");
	Xil_Out32(base_address+0,10);

	//read coeff output matrix
	printf("- Before\r\nC(0,0): %lu\r\nC(3,3): %lu\r\n",Xil_In32(base_address+136),Xil_In32(base_address+196));
	//write coeff
	XTime_GetTime(&begin1);
	Xil_Out32(base_address+8,0xff);
	Xil_Out32(base_address+68,0x80);
	Xil_Out32(base_address+72,0xf0);
	Xil_Out32(base_address+132,0x80);
	//start calc
//	XTime_GetTime(&begin1);
	Xil_Out32(base_address+0,0x1);
	//wait for calcul done
	while(!(Xil_In32(base_address+0)&2));
	XTime_GetTime(&end1);
	printf("Read TIMER: 0x%08x\r\n",Xil_In32(base_address+4));
	printf("Read TIMER: 0x%08x\r\n",Xil_In32(base_address+4));
	//read coeff output matrix
	printf("- After\r\nC(0,0): %lu\r\nC(3,3): %lu\r\n",Xil_In32(base_address+136),Xil_In32(base_address+196));
	printf("Computation time: %.9lf\r\n",(double)(end1-begin1)*(1.0/COUNTS_PER_SECOND));

	XTime_GetTime(&begin1);
	Xil_Out32(base_address+8,0xff);
	XTime_GetTime(&end1);
	printf("Time to write 1 register: %.9lf\r\n",(double)(end1-begin1)*(1.0/COUNTS_PER_SECOND));

	return 0;
}
