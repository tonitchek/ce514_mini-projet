/*
 * main.c
 *
 *  Created on: Dec 10, 2017
 *      Author: perrin
 */
#include <stdio.h>
#include <stdint.h>
#include <xil_io.h>
#include <xparameters.h>

#define CSR_OFFSET 0x0
#define MATA_ELEMENT_START_OFFSET 0x08
#define MATB_ELEMENT_START_OFFSET 0x48
#define MATC_ELEMENT_START_OFFSET 0x88

uint8_t check_output_matrix(uint32_t *matc, uint32_t *matc_ip)
{
	uint8_t i;
	for(i=0;i<16;i++)
	{
		if(matc[i] != matc_ip[i])
		{
			return 0;
		}
	}
	return 1;
}

void print_read_mat(uint32_t base_address, uint8_t start_offset)
{
	uint8_t i;
	for(i=0;i<16;i++)
	{
		if( (i % 4) != 0 )
		{
			printf("%lu\t",Xil_In32(base_address+start_offset+(i*4)));
		}
		else
		{
			printf("%lu\r\n",Xil_In32(base_address+start_offset+(i*4)));
		}
	}
	printf("\r\n");
}

int main(void)
{
	uint8_t i;

	printf("\r\n\r\n=== Unit Test Matrix Multiplier ===\r\n\r\n");

	//declare input matrices A and B
	uint8_t mata[16] = {
			255,255,255,254,
			2,240,8,24,
			153,171,254,1,
			120,52,51,144};

	uint8_t matb[16] = {
			255,5,17,122,
			255,98,201,11,
			255,27,2,233,
			255,190,176,10};

	//declare "TRUE" output matrix C
	uint32_t matc[16] = {
			260100,81600,100980,95880,
			69870,28306,52514,4988,
			147645,24571,37656,79739,
			93585,34433,37938,28535};

	//declare output matrix C computed from IP
	uint32_t matc_ip[16];

	//set IP base address
	uint32_t base_address = XPAR_MATRIX_4X4_MULTIPLIER_0_S00_AXI_BASEADDR;

	//load matrix A (row by row)
	for(i=0;i<16;i++)
	{
		Xil_Out32(base_address+MATA_ELEMENT_START_OFFSET+(i*4),(uint32_t)mata[i]);
	}
	//load matrix B (column by column)
	uint8_t j,k=0;
	for(i=0;i<4;i++)
	{
		for(j=0;j<4;j++)
		{
			Xil_Out32(base_address+MATB_ELEMENT_START_OFFSET+(k*4),(uint32_t)matb[i+j*4]);
			k++;
		}
	}

	//start IP calcul
	Xil_Out32(base_address+CSR_OFFSET,0x1);

	//store matrix C
	for(i=0;i<16;i++)
	{
		matc_ip[i] = Xil_In32(base_address+MATC_ELEMENT_START_OFFSET+(i*4));
	}

	//compare matrix
	if(check_output_matrix(matc,matc_ip))
	{
		//first calcul should not match!
		printf("!!!Unit Test FAILURE!!!\r\n");
		return 1;
	}

	//put right value in element (0,3) that should match comparison
	Xil_Out32(base_address+MATA_ELEMENT_START_OFFSET+0xC,(uint32_t)255);

	//start IP calcul
	Xil_Out32(base_address+CSR_OFFSET,0x1);

	//store matrix C
	for(i=0;i<16;i++)
	{
		matc_ip[i] = Xil_In32(base_address+MATC_ELEMENT_START_OFFSET+(i*4));
	}

	//compare matrix
	if(!check_output_matrix(matc,matc_ip))
	{
		printf("!!!Unit Test FAILURE!!!\r\n");
		return 1;
	}
	printf("+++Unit Test SUCCESS+++\r\n");


	return 0;
}
